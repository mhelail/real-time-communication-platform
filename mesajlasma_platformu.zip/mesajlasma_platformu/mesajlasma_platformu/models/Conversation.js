const mongoose = require('mongoose'); // Mongoose'u burada import edin

const conversationSchema = new mongoose.Schema({
  participants: [String], // Array of usernames that are part of the conversation
  type: {  // 'private' for individual chats, 'group' for group chats
    type: String,
    enum: ['private', 'group'],
    required: true,
  },
  name: { // Grup için grup adı
    type: String,
    required: function () {
      return this.type === 'group'; // Yalnızca grup konuşmaları için
    },
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  lastMessageTimestamp: {  // Son mesaj zamanını tutarak sıralama yapılabilir
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Conversation', conversationSchema);
