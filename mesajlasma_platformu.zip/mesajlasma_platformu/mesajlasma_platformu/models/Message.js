const mongoose = require('mongoose'); // Mongoose modülünü dahil edin

const messageSchema = new mongoose.Schema({

  conversationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Conversation', // Conversation modeline referans
    required: true,
  },
  from: { // Mesajı gönderen kullanıcı
    type: String,
    required: true,
  },
  to: { // Mesajın alıcısı (yalnızca bireysel sohbetlerde)
    type: String,
    required: function () {
      return this.type === 'private'; // Yalnızca bireysel sohbetlerde 'to' gerekli
    },
  },
  content: {
    type: String,
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Message', messageSchema);
