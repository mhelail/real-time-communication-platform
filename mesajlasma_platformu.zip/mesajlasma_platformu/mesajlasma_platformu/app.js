const fs = require('fs');
const https = require('https');
const http = require('http');
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const socketIo = require('socket.io');
const path = require('path');
const Message = require('./models/Message');
const User = require('./models/User');
const Conversation = require('./models/Conversation');
const authenticateToken = require('./controllers/authenticationToken');
const jwt = require('jsonwebtoken');

require('dotenv').config();

const app = express();

// Veritabanı bağlantısı
connectDB();
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'DELETE', 'PUT', 'OPTIONS'],
  credentials: true,
}));

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Rotalar
app.use('/api/auth', authRoutes);

// Sohbet arayüzü için HTML dosyasını sun
app.get('/chat', (req, res) => {
  res.sendFile(path.join(__dirname, 'chat.html'));
});

// Giriş/Kayıt Sayfalarını Sun
app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/register.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'register.html'));
});

// Kullanıcıları listele
app.get('/api/auth/users', async (req, res) => {
  try {
    const users = await User.find({}, { username: 1, _id: 0 });
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Tüm kullanıcılar yüklenemedi." });
  }
});

// Kullanıcı arama için rota
app.get('/api/auth/users/search', async (req, res) => {
  const { username } = req.query;
  try {
    const users = await User.find({ username: { $regex: username, $options: 'i' } }).select('username');
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: 'Kullanıcı ararken hata oluştu', error });
  }
});

// Mesajları listele
app.get('/api/auth/messages', authenticateToken, async (req, res) => {
  const { user } = req.query;
  const currentUser = req.user.username;
  const messages = await Message.find({
    $or: [
      { from: currentUser, to: user },
      { from: user, to: currentUser }
    ]
  }).sort({ timestamp: 1 });
  res.json(messages);
});

// Konuşmaları listele
app.get('/api/auth/conversations', authenticateToken, async (req, res) => {
  const currentUser = req.user.username;
  try {
    const conversations = await Conversation.find({ participants: { $in: [currentUser] } })
      .populate('participants', 'username');
    console.log("Conversations:", conversations); // Debug için çıktı
    res.status(200).json({ conversations });
  } catch (error) {
    console.error('Error fetching conversations:', error);
    res.status(500).json({ message: 'Konuşmalar alınırken hata oluştu', error });
  }
});

app.post('/api/auth/users/conversation', authenticateToken, async (req, res) => {
  const { username } = req.body;
  const currentUser = req.user.username;

  try {
    // Kullanıcıyla yeni bir konuşma başlatma işlemi
    const newConversation = new Conversation({
      participants: [currentUser, username],
      // Diğer gerekli alanları ekleyin
    });

    await newConversation.save();
    res.status(201).json({ conversationId: newConversation._id });
  } catch (error) {
    res.status(500).json({ message: 'Konuşma oluşturulurken hata oluştu', error });
  }
});


// Konuşma katılımcılarını listele
app.get('/api/auth/messages/participants', authenticateToken, async (req, res) => {
  const currentUser = req.user.username;
  const messages = await Message.find({
    $or: [{ from: currentUser }, { to: currentUser }]
  });
  const users = new Set();
  messages.forEach(msg => {
    if (msg.from !== currentUser) users.add(msg.from);
    if (msg.to !== currentUser) users.add(msg.to);
  });
  res.json(Array.from(users).map(username => ({ username })));
});
 
app.post('/api/auth/groups/:groupId/messages', authenticateToken, async (req, res) => {
  const { groupId } = req.params;
  try {
    const group = await Conversation.findById(groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const messages = await Message.find({ conversationId: groupId }).sort('timestamp');
    res.status(200).json({ messages });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching group messages', error });
  }
});

// Mesaj silme
app.delete('/api/auth/messages/:id', authenticateToken, async (req, res) => {
  const messageId = req.params.id;
  if (!messageId) {
    return res.status(400).json({ message: 'Message ID is required' });
  }

  try {
    const message = await Message.findByIdAndDelete(messageId);
    if (!message) {
      return res.status(404).json({ message: 'Message not found' });
    }
    res.status(200).json({ success: true, message: 'Message deleted successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete message.' });
  }
});

// Yeni grup oluşturma rotası
app.post('/api/auth/groups', authenticateToken, async (req, res) => {
  const { groupName, members } = req.body;

  try {
    const currentUser = req.user.username;
    const newGroup = new Conversation({
      type: 'group',
      participants: [currentUser, ...members],
      name: groupName,
    });

    await newGroup.save();
    res.status(201).json(newGroup);
  } catch (error) {
    res.status(500).json({ message: 'Grup oluşturulurken hata oluştu', error });
  }
});

// Grup konuşmasında mesaj gönder
app.post('/api/auth/groups/:groupId/messages', authenticateToken, async (req, res) => {
  const { groupId } = req.params;
  const { content } = req.body;  // Mesaj içeriği
  const from = req.user.username;  // Giriş yapan kullanıcı

  try {
    const group = await Conversation.findById(groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const newMessage = new Message({
      conversationId: groupId,
      from,
      content,
      timestamp: new Date(),
    });

    await newMessage.save();

    // Mesajı grup odasına yay
    io.to(groupId).emit('newMessage', {
      conversationId: groupId,
      from,
      content,
      timestamp: newMessage.timestamp,
    });

    res.status(201).json(newMessage);
  } catch (error) {
    res.status(500).json({ message: 'Failed to send message', error });
  }
});
app.get('/', (req, res) => {
  res.send('Sunucu başarıyla çalışıyor!');
});

const sslOptions = {
  key: fs.readFileSync('ssl/key.pem'),
  cert: fs.readFileSync('ssl/cert.pem'),
};

// SSL seçeneklerini ve mevcut uygulamayı kullanarak HTTPS sunucusu oluşturma
const PORT = process.env.PORT || 8443;
const httpsServer = https.createServer(sslOptions, app);

const io = socketIo(httpsServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// WebSocket bağlantılarını yönet
io.on('connection', (socket) => {
  console.log('Bir kullanıcı bağlandı:', socket.id);

    // Kullanıcı adı kaydetme
    socket.on('setUsername', (username) => {
      socket.username = username;
    });
  
    // Konuşma odasına katılma
    socket.on('joinConversation', (conversationId) => {
      if (conversationId) {
        socket.join(conversationId);
        console.log(`DEBUG: Kullanıcı ${socket.username} konuşma ${conversationId} odasına katıldı.`);
      } else {
        console.error("joinConversation: conversationId undefined!");
      }
    });
  
    // Grup odasına katılma
    socket.on('joinRoom', (data) => {
      const { groupId } = data;
      if (groupId) {
        socket.join(groupId);
        console.log(`User joined group ${groupId}`);
      } else {
        console.error("joinRoom: groupId undefined!");
      }
    });
  
    // Gelen mesajları yönetme ve yalnızca belirli konuşma odasına yayınlama
    socket.on('message', async (data) => {
      const { conversationId, from, content } = data;
      console.log("DEBUG: from:", from);
      console.log("DEBUG: content:", content);
      try {
        const conversation = await Conversation.findById(conversationId);
        if (!conversation) {
          console.error("DEBUG: Konuşma bulunamadı, ID:", conversationId);
          return;
        }
  
        const to = conversation.participants.find(participant => participant.toString() !== from);
        console.log("DEBUG: to:", to);
  
        if (!to) {
          console.error("DEBUG: Alıcı bulunamadı, katılımcılar:", conversation.participants);
          return;
        }
  
        const newMessage = new Message({
          conversationId,
          from,
          to,
          content,
          timestamp: new Date(),
        });
  
        await newMessage.save();
  
        io.to(conversationId).emit('newMessage', {
          conversationId: newMessage.conversationId,
          from: newMessage.from,
          content: newMessage.content,
          timestamp: newMessage.timestamp,
        });
  
        console.log("DEBUG: Mesaj başarıyla kaydedildi ve yayınlandı:", newMessage);
      } catch (error) {
        console.error('Mesaj kaydedilirken hata oluştu:', error);
      }
    });
  
    // Kullanıcı bağlantısını kesince
    socket.on('disconnect', () => {
      console.log('Bir kullanıcı bağlantısını kesti:', socket.id);
    });
});
  
// HTTPS sunucusunu başlat
httpsServer.listen(PORT, () => {
  console.log(`Sunucu, ${PORT} numaralı bağlantı noktasında güvenli bir şekilde çalışıyor.`);
});

const httpServer = http.createServer((req, res) => {
  res.writeHead(301, { Location: `https://${req.headers.host}${req.url}` });
  res.end();
});

httpServer.listen(8080, () => {
  console.log('HTTP sunucusu 8080 numaralı portta çalışıyor ve HTTPS yönlendirme yapıyor.');
});
