const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');

// Kullanıcı kaydı
exports.register = async (req, res) => {
    const { username, password } = req.body;

    // Kullanıcı var mı kontrol et
    const existingUser = await User.findOne({ username });
    if (existingUser) {
        return res.status(400).json({ message: 'Kullanıcı adı zaten alınmış' });
    }

    try {
        // Şifreyi hashle
        const hashedPassword = await bcrypt.hash(password, 10);

        // Yeni kullanıcı oluştur
        const newUser = new User({
            username,
            password: hashedPassword,
        });

        await newUser.save();
        res.status(201).json({ message: 'Kullanıcı başarıyla kaydedildi' });
    } catch (error) {
        res.status(500).json({ message: 'Kayıt hatası', error });
    }
};

// Kullanıcı girişi
exports.login = async (req, res) => {
    const { username, password } = req.body;

    try {
        // Kullanıcıyı bul
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ message: "Kullanıcı bulunamadı" });
        }

        // Şifreyi karşılaştır
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Şifre hatalı" });
        }

        // JWT tokenı oluştur
        const token = jwt.sign({ id: user._id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '1h' });

        // Başarılı giriş işlemleri
        res.status(200).json({ message: "Giriş başarılı", token });
    } catch (error) {
        res.status(500).json({ message: "Giriş hatası", error });
    }
};

// İki kullanıcı arasındaki konuşmayı oluştur veya bul
exports.createOrFindConversation = async (req, res) => {
    const { username } = req.body;
    const currentUsername = req.user.username;

    try {
        let conversation = await Conversation.findOne({
            participants: { $all: [currentUsername, username] }
        });

        if (!conversation) {
            conversation = new Conversation({
                type: 'private',
                participants: [currentUsername, username]
            });
            await conversation.save();
        }

        res.status(200).json({ conversationId: conversation._id });
    } catch (error) {
        res.status(500).json({ message: 'Konuşma oluşturulurken veya bulunurken hata oluştu', error });
    }
};

// Kullanıcıya ait konuşmaları al
exports.getConversations = async (req, res) => {
    const currentUsername = req.user.username;
  
    try {
      const conversations = await Conversation.find({ participants: currentUsername }).populate('participants', 'username');
      const conversationDetails = conversations.map(conversation => {
        if (conversation.type === 'group') {
          return {
            type: conversation.type,
            name: conversation.name,
            conversationId: conversation._id
          };
        } else {
          const participant = conversation.participants.find(participant => participant.username !== currentUsername);
          if (participant) {
            return {
              type: conversation.type,
              username: participant.username,
              conversationId: conversation._id
            };
          } else {
            console.error("DEBUG: Null participant found in conversation:", conversation);
            return null;
          }
        }
      }).filter(conversation => conversation !== null);
  
      res.status(200).json({ conversations: conversationDetails });
    } catch (error) {
      console.error('DEBUG: Error fetching conversations:', error.message);
      res.status(500).json({ message: 'Konuşmalar getirilirken hata oluştu', error: error.message });
    }
  };
  

// Kullanıcı araması
exports.searchUsers = async (req, res) => {
    let searchTerm = req.query.username ? req.query.username.trim() : "";
    const currentUsername = req.user.username;

    if (!searchTerm) {
        return this.getAllUsers(req, res); // Arama terimi yoksa tüm kullanıcıları listele
    }

    try {
        const regex = new RegExp(`^${searchTerm}`, 'i'); // Başlayan, büyük/küçük harf duyarsız

        const users = await User.find({
            username: { $regex: regex },  // Kullanıcı adı arama terimi ile başlayanları filtrele
            _id: { $ne: req.user.id }     // Mevcut kullanıcıyı hariç tut
        }).select('username _id');

        return res.status(200).json({ users });
    } catch (error) {
        console.error("DEBUG: Kullanıcılar aranırken hata oluştu:", error);
        return res.status(500).json({ message: 'Kullanıcı arama hatası', error });
    }
};

// Tüm kullanıcıları listele
exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.find({}).select('username _id'); // Sadece username ve _id bilgilerini alıyoruz
        res.status(200).json({ users });
    } catch (error) {
        console.error("DEBUG: Kullanıcılar alınırken hata oluştu:", error);
        res.status(500).json({ message: 'Kullanıcılar alınırken hata oluştu', error });
    }
};

// Bireysel konuşmanın mesajlarını getir
exports.getPrivateMessages = async (req, res) => {
    const { conversationId } = req.params;

    try {
        const messages = await Message.find({ conversationId }).sort('timestamp');
        res.status(200).json({ messages });
    } catch (error) {
        res.status(500).json({ message: 'Bireysel mesajlar getirilirken hata oluştu', error });
    }
};


// Grup konuşmasının mesajlarını al
exports.getGroupMessages = async (req, res) => {
  const { groupId } = req.params;  // Parametrelerden grup ID'sini al
  console.log(`DEBUG: getGroupMessages called with groupId: ${groupId}`);

  try {
    const messages = await Message.find({ conversationId: groupId }).sort('timestamp');  // Belirli konuşmaya ait mesajları sırala
    console.log(`DEBUG: Fetched messages:`, messages);

    res.status(200).json({ messages });
  } catch (error) {
    console.error('Error getting group messages:', error);
    res.status(500).json({ message: 'Grup mesajları getirilirken hata oluştu', error });
  }
};


// Bireysel konuşmada mesaj gönder
exports.sendMessage = async (req, res) => {
    const { conversationId, content } = req.body;
    const from = req.user.username;

    if (!conversationId || !content) {
        return res.status(400).json({ message: "Conversation ID and message content are required" });
    }

    try {
        const conversation = await Conversation.findById(conversationId);
        if (!conversation) {
            return res.status(404).json({ message: 'Conversation not found' });
        }

        // Identify the recipient
        const to = conversation.participants.find(participant => participant !== from);

        // Create and save the new message
        const newMessage = new Message({
            conversationId,
            from,
            to,
            content,
            timestamp: new Date() // Ensure timestamp is being recorded
        });

        await newMessage.save();

        res.status(201).json({ newMessage });
    } catch (error) {
        res.status(500).json({ message: "Error saving message", error });
    }
};

// Grup konuşmasında mesaj gönder
exports.sendGroupMessage = async (req, res) => {
  const { groupId } = req.params;
  const { content } = req.body;
  const from = req.user.username;

  try {
    const group = await Conversation.findById(groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const newMessage = new Message({
      conversationId: groupId, // Group ID olarak ayarladık
      from,
      content,
      timestamp: new Date(),
    });

    await newMessage.save();

    // Mesajı grup odasına yay
    io.to(groupId).emit('newMessage', {
      conversationId: groupId,
      from,
      content,
      timestamp: newMessage.timestamp,
    });

    res.status(201).json(newMessage);
  } catch (error) {
    res.status(500).json({ message: 'Failed to send message', error });
  }
};

  exports.getUserGroups = async (req, res) => {
    const currentUser = req.user.username;
  
    try {
      const groups = await Conversation.find({ participants: currentUser, type: 'group' })
        .populate('participants', 'username')
        .sort({ lastMessageTimestamp: -1 });
      res.status(200).json({ groups });
    } catch (error) {
      console.error('Error fetching user groups:', error);
      res.status(500).json({ message: 'Failed to fetch user groups', error });
    }
  };
  

// Yeni grup oluştur
exports.createGroup = async (req, res) => {
    const { groupName, members } = req.body;
    const currentUsername = req.user.username;
  
    if (!groupName || !members || members.length < 1) {
      return res.status(400).json({ message: 'Group name and at least one member are required' });
    }
  
    try {
      const newGroup = new Conversation({
        type: 'group',
        name: groupName,
        participants: [currentUsername, ...members],
      });
  
      await newGroup.save();
  
      res.status(201).json({ groupId: newGroup._id });
    } catch (error) {
      console.error('Error creating group:', error);
      res.status(500).json({ message: 'Failed to create group', error });
    }
  };
  
